import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { CurrentLoggedInUser } from '../../models/global/current-loggedin-user-model';
import { LoginResponse } from '../../models/global/login-response.model';
import { GlobalConstantService } from '../../models/global/global-constant';
import { UserRegistrationModel } from '../../models/system-user/user-registration-model';

@Injectable()
export class AuthenticationService {
        private currentLoggedInUser: CurrentLoggedInUser = new CurrentLoggedInUser();
        private loginResponse: LoginResponse = new LoginResponse();
        private apiBaseUrl = this.globalConstant.apiBaseUrl;

        constructor(private http: HttpClient, public globalConstant: GlobalConstantService) { }

        public validateLogin(email, password): Observable<LoginResponse> {
                var headers = new HttpHeaders();
                var body = {
                        "email": email,
                        "password": password
                }
                headers.append('Content-Type', 'application/x-www-form-urlencoded');
                return this.http.post(`${this.apiBaseUrl}/api/account/login`, body, { headers: headers })
                        .pipe(
                                map(response => {
                                        var apiResponse = JSON.parse(JSON.stringify(response));
                                        if (apiResponse.token.length > 0) {
                                                this.loginResponse.isSuccess = true;
                                                this.loginResponse.message = 'Success, Login successful!';
                                                this.loginResponse.token = apiResponse.token;
                                                this.loginResponse.userProfilePhotoUrl = '';
                                                this.loginResponse.currentLoggedInUser = apiResponse.currentUser;

                                                return this.loginResponse;
                                        }
                                        else {
                                                this.loginResponse.isSuccess = false;
                                                this.loginResponse.message = 'Warning, Incorrect email or password';
                                                return this.loginResponse;
                                        }
                                }

                                ));
        }

        public registerNewUser(model: UserRegistrationModel): Observable<LoginResponse> {
                var headers = new HttpHeaders();
                
                headers.append('Content-Type', 'application/x-www-form-urlencoded');
                return this.http.post(`${this.apiBaseUrl}/api/account/register`, model, { headers: headers })
                        .pipe(
                                map(response => {
                                        var apiResponse = JSON.parse(JSON.stringify(response));
                                        if (apiResponse && apiResponse.isSuccess) {
                                                this.loginResponse.isSuccess = true;
                                                this.loginResponse.message = 'Success, Registration Completed!';                                                
                                                return this.loginResponse;
                                        }
                                        else {
                                                this.loginResponse.isSuccess = false;
                                                this.loginResponse.message = 'Warning, There was an error while registering';
                                                return this.loginResponse;
                                        }
                                }

                                ));
        }

        public registerSocialMediaNewUser(model: UserRegistrationModel): Observable<LoginResponse> {
                var headers = new HttpHeaders();
                
                headers.append('Content-Type', 'application/x-www-form-urlencoded');
                return this.http.post(`${this.apiBaseUrl}/api/account/registerassocialmedia`, model, { headers: headers })
                        .pipe(
                                map(response => {
                                        var apiResponse = JSON.parse(JSON.stringify(response));
                                        if (apiResponse && apiResponse.isSuccess) {
                                                this.loginResponse.isSuccess = true;
                                                this.loginResponse.message = 'Success, Login successful!';
                                                this.loginResponse.token = apiResponse.token;
                                                this.loginResponse.userProfilePhotoUrl = '';
                                                this.loginResponse.currentLoggedInUser = apiResponse.currentUser;

                                                return this.loginResponse;
                                        }
                                        else {
                                                this.loginResponse.isSuccess = false;
                                                this.loginResponse.message = 'Warning, There was an error while registering';
                                                return this.loginResponse;
                                        }
                                }

                                ));
        }

        public getCurrentLoggedInUserData(token: string): Observable<CurrentLoggedInUser> {
                let headers = this.getHeader(token);
                return this.http.get(`${this.apiBaseUrl}/api/dashboard/myprofile`, { headers: headers })
                        .pipe(
                                map(response => {
                                        this.currentLoggedInUser = JSON.parse(JSON.stringify(response));
                                        return this.currentLoggedInUser;
                                })
                        );
        }

        public setLoggedInUserInfo(
                isSuccessLoggIn: boolean,
                token: string,
                isLoggedIn: string,
                currentLoggedInUser: CurrentLoggedInUser) {

                this.loginResponse.isSuccess = isSuccessLoggIn;
                this.loginResponse.token = token;
                this.currentLoggedInUser = currentLoggedInUser;
                localStorage.setItem('auth_token', this.loginResponse.token);
                localStorage.setItem('isLoggedIn', isLoggedIn);
                localStorage.setItem('currentUserInfo', JSON.stringify(currentLoggedInUser));
        }

        public validateLoggedInUser() {
                this.currentLoggedInUser = JSON.parse(localStorage.getItem('currentUserInfo'));

                if (this.currentLoggedInUser == null)
                        return false;

                var email = this.currentLoggedInUser.email;
                var passwordHash = this.currentLoggedInUser.passwordHash;
                var rememberMe = this.currentLoggedInUser.rememberMe;

                var credentialValidated = (email && email != '') && (passwordHash && passwordHash != '') ? true : false;
                if (credentialValidated && rememberMe)
                        return true;

                return false;
        }

        public getCurrentUserInfo() {
                let isLoggedIn = localStorage.getItem('isLoggedIn');
                if (isLoggedIn == 'yes') {
                        this.currentLoggedInUser = JSON.parse(localStorage.getItem('currentUserInfo'));
                }
                return this.currentLoggedInUser;
        }

        getLoggedInUserInfo() {
                let isLoggedIn = localStorage.getItem('isLoggedIn');
                if (isLoggedIn == 'yes') {
                        this.loginResponse.isSuccess = true;
                        this.loginResponse.message = 'User logged in successfully!';
                        this.loginResponse.token = localStorage.getItem('auth_token');                        
                }
                return this.loginResponse;
        }

        private getHeader(token: string): HttpHeaders {
                let headers = new HttpHeaders({ 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token });
                return headers;
        }
}
