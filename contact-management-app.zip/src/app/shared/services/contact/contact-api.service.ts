import { Injectable } from '@angular/core';

import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { GlobalConstantService } from '../../models/global/global-constant';
import { GlobalBaseResponse } from '../../models/global/global-base-response.model';

import { ContactModel } from '../../models/contacts/contact-model';
import { ContactSearchFilter } from '../../models/contacts/contact-search-filter';

@Injectable()
export class ContactService {
        private contactListing: ContactModel[];
        private contactModel: ContactModel = new ContactModel();

        private globalBaseResponse: GlobalBaseResponse = <any>{};
        private apiBaseUrl = this.globalConstant.apiBaseUrl;
        constructor(
                private http: HttpClient,
                public globalConstant: GlobalConstantService
        ) { }

        public getContactDetails(id: number, token: string): Observable<any> {
                let headers = this.getHeader(token);
                return this.http.get(`${this.apiBaseUrl}/api/contact/details/${id}`, { headers: headers })
                        .pipe(
                                map(response => {
                                        this.contactModel = JSON.parse(JSON.stringify(response));
                                        return this.contactModel;
                                })
                        );
        }


        filterContacts(searchFilter: ContactSearchFilter): Observable<any> {
                let headers = this.getHeader(searchFilter.token);
                return this.http.post(`${this.globalConstant.apiBaseUrl}/api/contact/getcontactbyfilter`,
                        JSON.stringify(searchFilter),
                        {
                                headers: headers
                        }
                )
                        .pipe(
                                map(response => {
                                        let dataModel = JSON.parse(JSON.stringify(response));
                                        return dataModel;
                                })
                        );
        }

        public addContact(token: string, model: ContactModel): Observable<GlobalBaseResponse> {
                let headers = this.getHeader(token);
                return this.http.post(`${this.globalConstant.apiBaseUrl}/api/contact/add`, JSON.stringify(model), { headers: headers })
                        .pipe(
                                map(response => {
                                        this.globalBaseResponse = JSON.parse(JSON.stringify(response));
                                        return this.globalBaseResponse;
                                })
                        );
        }

        public updateContact(token: string, model: ContactModel): Observable<GlobalBaseResponse> {
                let headers = this.getHeader(token);
                return this.http.post(`${this.globalConstant.apiBaseUrl}/api/contact/update`, JSON.stringify(model), { headers: headers })
                        .pipe(
                                map(response => {
                                        this.globalBaseResponse = JSON.parse(JSON.stringify(response));
                                        return this.globalBaseResponse;
                                })
                        );
        }

        removeContact(token: string, contactId: number): Observable<GlobalBaseResponse> {
                let headers = this.getHeader(token);
                return this.http.get(`${this.globalConstant.apiBaseUrl}/api/contact/remove/${contactId}`, { headers: headers })
                        .pipe(
                                map(response => {
                                        this.globalBaseResponse = JSON.parse(JSON.stringify(response));
                                        return this.globalBaseResponse;
                                })
                        );
        }

        public importContacts(token: string,formData: FormData): Observable<GlobalBaseResponse> {
                let headers = this.getFileUploadHeader(token);//note: you must have to use this header when upload file on post method                
                var options = { content: formData };
                return this.http.post(`${this.globalConstant.apiBaseUrl}/api/contact/ImportContact`, formData 
                ,{ headers: headers }
                )
                        .pipe(
                                map(response => {
                                        this.globalBaseResponse = JSON.parse(JSON.stringify(response));
                                        return this.globalBaseResponse;
                                })
                        );
        }

        private getFileUploadHeader(token:string):HttpHeaders{
                let headers = new HttpHeaders({ 
                        //'Data-Type': 'json',
                        'accept':'application/json',                         
                        // 'Process-Data':'false',
                        'Authorization':'Bearer '+token 
                });

                return headers;
        }

        private getHeader(token: string): HttpHeaders {
                let headers = new HttpHeaders({ 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token });
                return headers;
        }
}
