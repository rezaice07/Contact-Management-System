import { Injectable } from '@angular/core';

import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { GlobalConstantService } from '../../models/global/global-constant';
import { GlobalBaseResponse } from '../../models/global/global-base-response.model';

import { CategoryModel } from '../../models/categories/category-model';
import { CategorySearchFilter } from '../../models/categories/category-search-filter';

@Injectable()
export class CategoryService {
        private categoryListing: CategoryModel[];
        private categoryModel: CategoryModel = new CategoryModel();

        private globalBaseResponse: GlobalBaseResponse = <any>{};
        private apiBaseUrl = this.globalConstant.apiBaseUrl;
        constructor(
                private http: HttpClient,
                public globalConstant: GlobalConstantService
        ) { }

        public getCategoryDetails(id: number, token: string): Observable<CategoryModel> {
                let headers = this.getHeader(token);
                return this.http.get(`${this.apiBaseUrl}/api/category/details/${id}`, { headers: headers })
                        .pipe(
                                map(response => {
                                        this.categoryModel = JSON.parse(JSON.stringify(response));
                                        return this.categoryModel;
                                })
                        );
        }


        filterCategory(searchFilter: CategorySearchFilter): Observable<any> {
                let headers = this.getHeader(searchFilter.token);
                return this.http.post(`${this.globalConstant.apiBaseUrl}/api/category/getcategorybyfilter`,
                        JSON.stringify(searchFilter),
                        {
                                headers: headers
                        }
                )
                        .pipe(
                                map(response => {
                                        let dataModel = JSON.parse(JSON.stringify(response));
                                        return dataModel;
                                })
                        );
        }

        public addCategory(token: string, model: CategoryModel): Observable<GlobalBaseResponse> {
                let headers = this.getHeader(token);
                return this.http.post(`${this.globalConstant.apiBaseUrl}/api/category/add`, JSON.stringify(model), { headers: headers,withCredentials: true })
                        .pipe(
                                map(response => {
                                        this.globalBaseResponse = JSON.parse(JSON.stringify(response));
                                        return this.globalBaseResponse;
                                })
                        );
        }

        public updateCategory(token: string, model: CategoryModel): Observable<GlobalBaseResponse> {
                let headers = this.getHeader(token);
                return this.http.post(`${this.globalConstant.apiBaseUrl}/api/category/update`, JSON.stringify(model), { headers: headers })
                        .pipe(
                                map(response => {
                                        this.globalBaseResponse = JSON.parse(JSON.stringify(response));
                                        return this.globalBaseResponse;
                                })
                        );
        }

        public removeCategory(token: string, categoryId: number): Observable<GlobalBaseResponse> {
                let headers = this.getHeader(token);
                return this.http.get(`${this.globalConstant.apiBaseUrl}/api/category/remove/${categoryId}`, { headers: headers })
                        .pipe(
                                map(response => {
                                        this.globalBaseResponse = JSON.parse(JSON.stringify(response));
                                        return this.globalBaseResponse;
                                })
                        );
        }

        public getCategoryDropdownItems(token: string): Observable<any> {
                let headers = this.getHeader(token);
                return this.http.get(`${this.globalConstant.apiBaseUrl}/api/category/getcategorydropdownitems`, { headers: headers })
                        .pipe(
                                map(response => {
                                        let items = JSON.parse(JSON.stringify(response));
                                        return items;
                                })
                        );
        }

        private getHeader(token: string): HttpHeaders {
                let headers = new HttpHeaders({ 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token });
                return headers;
        }
}
