import { Injectable } from '@angular/core';
@Injectable()

export class UrlSlugGenerator {
    constructor() {
    }

    public Generator(plainText:any){
        return plainText
            .replace(/^\s\s*/, '') // Trim start
            .replace(/\s\s*$/, '') // Trim end
            .toLowerCase() // Camel case is bad
            .replace(/[^a-z0-9_\-~!\+\s]+/g, '') // Exchange invalid chars
            .replace(/[\s]+/g, '-'); // Swap whitespace for single 
      }
}