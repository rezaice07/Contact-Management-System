

export class SystemUserSearchFilter {
  searchTerm: any;
  startDate: any;
  endDate:any;   
  message:any;
  pageNumber: number = 1;
  pageSize: number =200;
}