

export class UserRegistrationModel {
    public name: string;
    public address: string;
    public password: string;
    public confirmPassword: string;
    public email: string;
    public mobile: string
    public dateOfBith: any;
    public photoUrl: any;
    public authToken: string;
    public idToken: string;
    public authorizationCode: string;
    public providerType: string;
}