

export class SystemUser {
  Id:any;
  Username:any;
  FirstName:any;
  LastName: any;
  Email:any;  
  Mobile: any;
  ProfilePhoto:any;
  ProfilePhotoUrl:any;
  Gender: any;
  NoofFalseTries: any;
  LastLogin: any;
  FullName: any; 
  IsAuthenticated: any;
}