

export class CategoryModel {
  public id:any;
  public name:any;  
}


