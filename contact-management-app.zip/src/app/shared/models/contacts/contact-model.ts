

export class ContactModel {
  public id:any;
  public categoryId:any;
  public name:any;
  public email: any;
  public mobile:any;
  public address:any;
}


