

export class ContactSearchFilter {
  searchTerm: any; 
  message:any;
  pageNumber: number = 1;
  pageSize: number =10;
  token:string;
  sortColumn:string;
  sortDirection:string;
}