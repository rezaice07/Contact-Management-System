
import { Injectable } from '@angular/core';

export class ReligionModel {
  Id:any;
  ReligionName:any; 
  constructor(id:any, religionName:any) {
      this.Id = id;
      this.ReligionName = religionName;
  }
}