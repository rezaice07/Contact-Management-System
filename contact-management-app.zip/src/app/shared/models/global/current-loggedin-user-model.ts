

export class CurrentLoggedInUser {
  id:any;
  name:any;  
  email:any;  
  address: any;
  mobile: any; 
  isAuthenticated: any;
  password:any;
  passwordHash:any;
  confirmPassword:any;
  rememberMe:any;
  roleId:number;
  status:number;
  roleName:any;
}