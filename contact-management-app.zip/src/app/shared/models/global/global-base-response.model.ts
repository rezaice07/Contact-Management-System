export class GlobalBaseResponse {
    public IsSuccess:any;
    public isSuccess:any;
    public message: any;
    public Id:any;
}