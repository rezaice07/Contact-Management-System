export class KeyContainer {
    
    authenticationToken: string = "authenticationToken";
    /**event keys */
    eventTokenChanged: string = 'token:changed';

    eventCurrentLoggedInUserChanged: string = 'currentLoggedInUserChanged:changed';
   
}