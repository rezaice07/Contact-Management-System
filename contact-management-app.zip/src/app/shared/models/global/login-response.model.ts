import { CurrentLoggedInUser } from './current-loggedin-user-model';

export class LoginResponse {
    public isSuccess:any;
    public message: any;
    public token:any;
    public userProfilePhotoUrl:any;
    public currentLoggedInUser:CurrentLoggedInUser;
}