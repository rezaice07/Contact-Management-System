
import { Injectable } from '@angular/core';

export class LanguageEficiencyModel {
  Id:any;
  EficiencyName:any; 
  constructor(id:any, eficiencyName:any) {
      this.Id = id;
      this.EficiencyName = eficiencyName;
  }
}