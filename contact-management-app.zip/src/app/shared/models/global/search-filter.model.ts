export class SearchFilter {
    searchTerm: any;
    startDate: any;
    endDate:any;
    pin:any;
    message:any;
  pageNumber: number = 1;
  pageSize: number =200;
}