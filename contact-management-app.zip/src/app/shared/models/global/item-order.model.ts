export class ItemOrder {
    CategoryId: any;
    itemId: any;
    productId:any;
    pin:any;
    message:any;
    isSuccess:any;
}