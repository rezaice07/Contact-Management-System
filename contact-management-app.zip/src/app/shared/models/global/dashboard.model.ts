export class Dashboard {
    Error:boolean;
    Message:any;
    dashboardCounts: any;
    orders: any;
    user:any;
    categories: any;
    products: any;
    items: any;
}