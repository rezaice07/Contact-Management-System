import { Injectable } from '@angular/core';
import { LanguageEficiencyModel } from '../global/language-eficiency-type-model';

@Injectable()
export class LanguageEficiencyTypeService {
  LanguageEficiencies: LanguageEficiencyModel[]=[];
  newLanguageEficiency:LanguageEficiencyModel;

  constructor() { }

  GetAllLanguageEficiencys(){                
    this.LanguageEficiencies=[];
    
    this.LanguageEficiencies.push(
        this.newLanguageEficiency={
          Id:'H',
          EficiencyName:'High'
        }
    );

    this.LanguageEficiencies.push(
      this.newLanguageEficiency={
        Id:'M',
        EficiencyName:'Medium'
      }
    );
    this.LanguageEficiencies.push(
      this.newLanguageEficiency={
        Id:'L',
        EficiencyName:'Low'
      }
    );  

    return this.LanguageEficiencies;
  }  
}

