import { Injectable } from '@angular/core';
import { ReligionModel } from '../global/Religion-model';

@Injectable()
export class ReligionService {
  religions: ReligionModel[]=[];
  newReligion:ReligionModel;

  constructor() { }

  GetAllReligions(){                
    
    this.religions.push(
        this.newReligion={
          Id:'I',
          ReligionName:'Islam'
        }
    );

    this.religions.push(
      this.newReligion={
        Id:'H',
        ReligionName:'Hindu'
      }
    );
    this.religions.push(
      this.newReligion={
        Id:'C',
        ReligionName:'Christianity'
      }
    );  
    this.religions.push(
      this.newReligion={
        Id:'B',
        ReligionName:'Buddhism'
      }
    );     

    return this.religions;
  }  
}

