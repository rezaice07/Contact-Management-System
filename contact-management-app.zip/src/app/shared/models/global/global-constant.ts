import { Injectable } from '@angular/core';


@Injectable()
export class GlobalConstantService {
    authenticationToken: string = "authenticationToken";
    currentLoggedInUserKey: string = "currentLoggedInUserKey";
    /**event keys */
    eventTokenChanged: string = 'token:changed';

    eventCurrentLoggedInUserChanged: string = 'currentLoggedInUserChanged:changed';

     apiBaseUrl:string = 'https://localhost:44386';

     ProfileImage:string='assets/img/profile/';     
}