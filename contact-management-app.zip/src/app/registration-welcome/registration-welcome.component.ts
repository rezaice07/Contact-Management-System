import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registration-welcome',
  templateUrl: './registration-welcome.component.html',
  styleUrls: ['./registration-welcome.component.css']
})
export class RegistrationWelcomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
