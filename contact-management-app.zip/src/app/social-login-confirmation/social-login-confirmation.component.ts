import { Component, OnInit } from '@angular/core';
import { AuthService, SocialUser, GoogleLoginProvider, FacebookLoginProvider, LinkedInLoginProvider } from 'angularx-social-login';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthenticationService } from '../shared/services/authentication/authenticationService';
import { UserRegistrationModel } from '../shared/models/system-user/user-registration-model';
import { LoginResponse } from '../shared/models/global/login-response.model';
import { CurrentLoggedInUser } from '../shared/models/global/current-loggedin-user-model';

@Component({
  selector: 'app-social-login-confirmation',
  templateUrl: './social-login-confirmation.component.html',
  styleUrls: ['./social-login-confirmation.component.css']
})

//reference
//https://www.npmjs.com/package/angularx-social-login
export class SocialLoginConfirmationComponent implements OnInit {

  private user: SocialUser;
  private providerType: any;
  private model: UserRegistrationModel = new UserRegistrationModel();
  private loginResponse: LoginResponse = new LoginResponse();
  private currentLoggedInUser: CurrentLoggedInUser = new CurrentLoggedInUser();
  
  constructor(private socialAuthService: AuthService,
    private router: Router,
    private authenticationService: AuthenticationService,
    private activatedRoute: ActivatedRoute) {
  }

  ngOnInit() {
    this.activatedRoute.params.subscribe(params => {
      this.providerType = params['providertype'];
    });

    if (this.providerType === "facebook") {
      this.facebookLogin()
    }

    if (this.providerType === "google") {
      this.googleLogin()
    }

    if (this.providerType === "linkedin") {
      this.linkedInLogin()
    }
  }

  facebookLogin() {
    this.socialAuthService.signIn(FacebookLoginProvider.PROVIDER_ID).then((userData) => {
      this.user = userData;
      this.model.providerType = "Facebook";
      this.registerNewUser();
    });
  }

  googleLogin() {
    this.socialAuthService.signIn(GoogleLoginProvider.PROVIDER_ID).then((userData) => {
      this.user = userData;
      this.model.providerType = "Google";
      this.registerNewUser();
    });
  }

  linkedInLogin() {
    this.socialAuthService.signIn(LinkedInLoginProvider.PROVIDER_ID).then((userData) => {
      this.user = userData;
      this.model.providerType = "LinkedIn";
      this.registerNewUser();
    });
  }

  private registerNewUser() {

    this.model.name = this.user.name;
    this.model.email = this.user.email;
    this.model.photoUrl = this.user.photoUrl;
    this.model.authToken = this.user.authToken;
    this.model.idToken = this.user.idToken;
    this.model.authorizationCode = this.user.authorizationCode;

    //let's validate authentication
    this.authenticationService.registerSocialMediaNewUser(this.model).subscribe(data => {
      this.loginResponse = data;

      if (data.isSuccess) {
        this.currentLoggedInUser = data.currentLoggedInUser;        
        this.currentLoggedInUser.rememberMe = false;

        // lets store user details     
        this.authenticationService.setLoggedInUserInfo(
          this.loginResponse.isSuccess,
          this.loginResponse.token,          
          'yes',
          this.currentLoggedInUser
        );
        this.router.navigate(['./dashboard']);

      }
      else {
        this.router.navigate([`./home`]);
      }
    }, err => {
      this.router.navigate([`./home`]);
    });
  }
}
