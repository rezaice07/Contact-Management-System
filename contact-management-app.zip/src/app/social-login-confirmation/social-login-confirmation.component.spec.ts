import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SocialLoginConfirmationComponent } from './social-login-confirmation.component';

describe('SocialLoginConfirmationComponent', () => {
  let component: SocialLoginConfirmationComponent;
  let fixture: ComponentFixture<SocialLoginConfirmationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SocialLoginConfirmationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SocialLoginConfirmationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
