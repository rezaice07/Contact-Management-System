import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AuthGuardGuard } from './auth-guard.guard';
import { RegistrationWelcomeComponent } from './registration-welcome/registration-welcome.component';

import { CategoryEditComponent } from './category/category-edit/category-edit.component';
import { ContactAddComponent } from './contact/contact-add/contact-add.component';
import { ContactEditComponent } from './contact/contact-edit/contact-edit.component';
import { CategoryListingComponent } from './category/category-listing/category-listing.component';
import { ContactListingComponent } from './contact/contact-listing/contact-listing.component';
import { CategoryAddComponent } from './category/category-add/category-add.component';
import { ImportContactComponent } from './import-contact/import-contact.component';
import { SocialLoginConfirmationComponent } from './social-login-confirmation/social-login-confirmation.component';

const routes: Routes = [
  {
    path: '',
    component: HomeComponent
  },
  {
    path: 'home',
    component: HomeComponent
  },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'register',
    component: RegisterComponent
  },
  {
    path: 'registrationconfirmation',
    component: RegistrationWelcomeComponent
  },
  {
    path: 'dashboard',
    canActivate:[AuthGuardGuard],  
    component: DashboardComponent
  },
  {
    path: 'categorylisting',
    canActivate:[AuthGuardGuard],  
    component: CategoryListingComponent
  },  
  {
    path: 'category/add',  
    canActivate:[AuthGuardGuard],  
    component: CategoryAddComponent
  },
  {
    path: 'category/edit/:id',  
    canActivate:[AuthGuardGuard],  
    component: CategoryEditComponent
  },

  {
    path: 'contactlisting',
    canActivate:[AuthGuardGuard],  
    component: ContactListingComponent
  },  
  {
    path: 'contact/add',  
    canActivate:[AuthGuardGuard],  
    component: ContactAddComponent
  },
  {
    path: 'contact/:id/edit/:guid',
    canActivate:[AuthGuardGuard],  
    component: ContactEditComponent
  },
  {
    path: 'contact/import',
    canActivate:[AuthGuardGuard],  
    component: ImportContactComponent
  },
   {
    path: 'sociallogin/:providertype/confirmation', 
    component: SocialLoginConfirmationComponent
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
