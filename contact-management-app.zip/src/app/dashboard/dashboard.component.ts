import { Component, OnInit } from '@angular/core';
import { PageChangeEvent, GridDataResult } from '@progress/kendo-angular-grid';
import { SortDescriptor } from '@progress/kendo-data-query';
import { Router } from '@angular/router';

import { LoginResponse } from '../shared/models/global/login-response.model';
import { GlobalBaseResponse } from '../shared/models/global/global-base-response.model';
import { CurrentLoggedInUser } from '../shared/models/global/current-loggedin-user-model';
import { AuthenticationService } from '../shared/services/authentication/authenticationService';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  public currentUserFirstname: string = "";

  //common variables  
  private loginResponse: LoginResponse = new LoginResponse();
  private currentLoggedInUser: CurrentLoggedInUser = new CurrentLoggedInUser();

  constructor(private router:Router,
    private authenticationService: AuthenticationService) { }

  ngOnInit() {
    this.currentLoggedInUser = this.authenticationService.getCurrentUserInfo();
    this.loginResponse = this.authenticationService.getLoggedInUserInfo();

    this.currentUserFirstname = this.currentLoggedInUser.name;
  }  
}
