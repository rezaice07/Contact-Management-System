import { Component, OnInit, ElementRef } from '@angular/core';
import { LoginResponse } from 'src/app/shared/models/global/login-response.model';
import { GlobalBaseResponse } from 'src/app/shared/models/global/global-base-response.model';
import { CurrentLoggedInUser } from 'src/app/shared/models/global/current-loggedin-user-model';
import { AuthenticationService } from 'src/app/shared/services/authentication/authenticationService';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators, AbstractControl } from '@angular/forms';

import { ContactService } from 'src/app/shared/services/contact/contact-api.service';
import { ContactModel } from 'src/app/shared/models/contacts/contact-model';
import { CategoryService } from 'src/app/shared/services/category/category-api.service';

@Component({
  selector: 'app-import-contact',
  templateUrl: './import-contact.component.html',
  styleUrls: ['./import-contact.component.css']
})
export class ImportContactComponent implements OnInit {

  //common variables  
  private loginResponse: LoginResponse = new LoginResponse();
  private globalBaseResponse: GlobalBaseResponse = new GlobalBaseResponse();

  private model: ContactModel = new ContactModel();
  private categories: [];
  private validationMessage: any;

  constructor(private contactService: ContactService,
    private router: Router,
    private elem: ElementRef,
    private categoryService: CategoryService,
    private authenticationService: AuthenticationService) { }

  ngOnInit() {
    this.loginResponse = this.authenticationService.getLoggedInUserInfo();

    //load category items
    this.getCategoryDropdownItems();
  }

  private importContact() {

    let files = this.elem.nativeElement.querySelector('#uploadDocument').files;
    if (!files || files.length <= 0) {
      this.validationMessage = "Please upload contact.";
      return;
    }

    if (files.length > 0) {
      const formData= new FormData();
      let file = files[0];

      let fileName=`categoryid:${this.model.categoryId}_fileName:${file.name}`;
      formData.append('uploadDocument', file, fileName);
      this.contactService.importContacts(this.loginResponse.token, formData).subscribe(data => {
        this.globalBaseResponse = data;
        if (data.isSuccess) {
          this.router.navigate(['./contactlisting']);
        }
      },
        err => {
          this.validationMessage =  this.globalBaseResponse.message;
        });
    }
  }

  private getCategoryDropdownItems() {
    this.categoryService.getCategoryDropdownItems(this.loginResponse.token)
      .subscribe(data => {
        this.categories = data.categories;
      });

    this.model.categoryId = "";
  }
}
