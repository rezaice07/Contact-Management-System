import { Component, OnInit } from '@angular/core';
import { LoginResponse } from 'src/app/shared/models/global/login-response.model';
import { GlobalBaseResponse } from 'src/app/shared/models/global/global-base-response.model';
import { CurrentLoggedInUser } from 'src/app/shared/models/global/current-loggedin-user-model';
import { AuthenticationService } from 'src/app/shared/services/authentication/authenticationService';
import { Router, ActivatedRoute } from '@angular/router';

import { ContactService } from 'src/app/shared/services/contact/contact-api.service';
import { ContactModel } from 'src/app/shared/models/contacts/contact-model';
import { CategoryService } from 'src/app/shared/services/category/category-api.service';

@Component({
  selector: 'app-contact-edit',
  templateUrl: './contact-edit.component.html',
  styleUrls: ['./contact-edit.component.css']
})
export class ContactEditComponent implements OnInit {

  //common variables  
  private loginResponse: LoginResponse = new LoginResponse();
  private globalBaseResponse: GlobalBaseResponse = new GlobalBaseResponse();

  private model: ContactModel = new ContactModel();
  private categories: [];
  private contactId: any;
  constructor(private contactService: ContactService,
    private router: Router,
    private categoryService: CategoryService,
    private activatedRoute: ActivatedRoute,
    private authenticationService: AuthenticationService) { }

  ngOnInit() {
    this.loginResponse = this.authenticationService.getLoggedInUserInfo();

    this.activatedRoute.params.subscribe(params => {
      this.contactId = params['id'];
    });

    //load category items
    this.getCategoryDropdownItems();

    this.getContactDetails();
  }

  private udateContact() {
    this.contactService.updateContact(this.loginResponse.token, this.model).subscribe(data => {
      this.globalBaseResponse = data;

      if (data.isSuccess) {
        this.router.navigate(['./contactlisting']);
      }
    }, err => {
      this.router.navigate([`./contactlisting`]);
    });
  }

  private getContactDetails() {
    this.contactService.getContactDetails(this.contactId,this.loginResponse.token)
      .subscribe(data => {
        this.model = data;
      });
  }

  private getCategoryDropdownItems() {
    this.categoryService.getCategoryDropdownItems(this.loginResponse.token)
      .subscribe(data => {
        this.categories = data.categories;
      });

    this.model.categoryId = "";
  }

}
