import { Component, OnInit } from '@angular/core';
import { PageChangeEvent, GridDataResult } from '@progress/kendo-angular-grid';
import { SortDescriptor } from '@progress/kendo-data-query';
import { Router } from '@angular/router';

import { LoginResponse } from 'src/app/shared/models/global/login-response.model';
import { CurrentLoggedInUser } from 'src/app/shared/models/global/current-loggedin-user-model';
import { AuthenticationService } from 'src/app/shared/services/authentication/authenticationService';
import { GlobalBaseResponse } from 'src/app/shared/models/global/global-base-response.model';

import { ContactService } from 'src/app/shared/services/contact/contact-api.service';
import { ContactSearchFilter } from 'src/app/shared/models/contacts/contact-search-filter';
import { ContactModel } from 'src/app/shared/models/contacts/contact-model';
import { UrlSlugGenerator } from 'src/app/shared/Helper/url-slug-generator';

@Component({
  selector: 'app-contact-listing',
  templateUrl: './contact-listing.component.html',
  styleUrls: ['./contact-listing.component.css']
})
export class ContactListingComponent implements OnInit {

  private contactSearchFilter: ContactSearchFilter = new ContactSearchFilter();
  private globalBaseResponse: GlobalBaseResponse = new GlobalBaseResponse();
  //common variables  
  private loginResponse: LoginResponse = new LoginResponse();
  private currentLoggedInUser: CurrentLoggedInUser = new CurrentLoggedInUser();

  //kendo grid settings
  public gridView: GridDataResult;
  public buttonCount: number = 5;
  public info = true;
  public type: 'numeric';
  public pageSizes: boolean = true;
  public previousNext: boolean = true;

  private searchTerm: string = '';
  private pageNumber: any = 1;
  private sortColumn = "name";
  private sortDirection = "asc";
  public pageSize = 20;
  public skip = 0;

  public multiple = false;
  public allowUnsort = false;

  //default sort directions
  public sort: SortDescriptor[] = [{
    field: 'category.name',
    dir: 'asc'
  }];

  constructor(private contactService: ContactService,
    private router: Router,
    private urlSlugGenerator: UrlSlugGenerator,
    private authenticationService: AuthenticationService) { }

  ngOnInit() {

    this.currentLoggedInUser = this.authenticationService.getCurrentUserInfo();
    this.loginResponse = this.authenticationService.getLoggedInUserInfo();

    //get list 
    this.pageNumber = 1;
    this.filterContactData();
  }
  protected pageChange({ skip, take }: PageChangeEvent): void {
    this.skip = skip;
    this.pageSize = take;
    this.getPageNumber(skip, take);

    //get list 
    this.filterContactData();
  }

  private filter(): void {
    this.filterContactData();
  }

  public sortChange(sort: SortDescriptor[]): void {
    this.sort = sort;
    this.getSortOptions(sort);

    //get list 
    this.filterContactData();
  }

  private filterContactData() {
    this.initializationSearchFilter();
    let that = this;

    this.contactService.filterContacts(that.contactSearchFilter)
      .subscribe(data => {
        var classViewModel = data;

        this.gridView = {
          data: classViewModel.model.contacts,
          total: classViewModel.model.searchFilter.totalCount
        };

      });
  }

  private remove(id: any) {
    this.contactService.removeContact(this.loginResponse.token, id).subscribe(data => {
      this.globalBaseResponse = data;

      if (data.isSuccess) {
        this.pageNumber=1;
        //get list 
        this.filterContactData();
      }
    }, err => {

    });
  }

  private refreshFirsteredListing():void{
    this.searchTerm="";
    //get list 
    this.filterContactData();
  }

  private redirectToContactEdit(contactModel : ContactModel) {
    if (contactModel.id > 0) {
      let urlSlug= this.urlSlugGenerator.Generator(contactModel.name);
      this.router.navigate([`contact/${contactModel.id}/edit/${urlSlug}`]);
    }
  } 

  private initializationSearchFilter() {
    this.contactSearchFilter.searchTerm = this.searchTerm;
    this.contactSearchFilter.sortColumn = this.sortColumn;
    this.contactSearchFilter.sortDirection = this.sortDirection;

    this.contactSearchFilter.token = this.loginResponse.token;
    this.contactSearchFilter.pageSize = this.pageSize;
    this.contactSearchFilter.pageNumber = this.pageNumber > 0 ? this.pageNumber : 1;
  }

  private getPageNumber(skip: number, pageSize: number): void {
    this.pageNumber = (skip + pageSize) / pageSize;
  }

  private getSortOptions(sort: SortDescriptor[]): void {
    this.sortColumn = sort[0].field;
    this.sortDirection = sort[0].dir;
  }
}
