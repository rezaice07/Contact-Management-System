import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../shared/services/authentication/authenticationService';
import { LoginResponse } from '../shared/models/global/login-response.model';
import { CurrentLoggedInUser } from '../shared/models/global/current-loggedin-user-model';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  private loginResponse: LoginResponse = new LoginResponse();
  private currentLoggedInUser: CurrentLoggedInUser = new CurrentLoggedInUser();

  private reCaptchKey: string = "";
  private Email: string = '';
  private Password: string = '';
  private RememberMe: any;

  constructor(private router: Router,
    private authenticationService: AuthenticationService
  ) {
    
  }

  ngOnInit() {    
    this.reCaptchKey = "6Ld7nnUUAAAAACHwRZgOeQP5daVE6ScP1aUk8P4F";
    this.redirectToLandingPage();
  }

  private redirectToLandingPage(): void {
    var loggedIn=this.authenticationService.validateLoggedInUser();
    if (!loggedIn) {
      this.router.navigate([`./login`]);
    }
    else {
      this.router.navigate([`./dashboard`]);
    }
  }

  private redirectToSocialLogin(provider:any) {   
      this.router.navigate([`sociallogin/${provider}/confirmation`]);   
  } 

  private login() {
    //let's validate authentication
    this.authenticationService.validateLogin(this.Email, this.Password).subscribe(data => {
      this.loginResponse = data;

      if (data.isSuccess) {
        this.currentLoggedInUser = data.currentLoggedInUser;        
        this.currentLoggedInUser.rememberMe = this.RememberMe;

        // lets store user details     
        this.authenticationService.setLoggedInUserInfo(
          this.loginResponse.isSuccess,
          this.loginResponse.token,          
          'yes',
          this.currentLoggedInUser
        );
        this.router.navigate(['./dashboard']);
      }
      else {
        this.router.navigate([`./home`]);
      }
    }, err => {
      this.router.navigate([`./home`]);
    });
  }

}
