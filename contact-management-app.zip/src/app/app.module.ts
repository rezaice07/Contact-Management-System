import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule }   from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HttpClientModule }    from '@angular/common/http';

//for google recaptcha
import { RecaptchaModule } from 'ng-recaptcha';
// if you need forms support:
import { RecaptchaFormsModule } from 'ng-recaptcha/forms';
import { AppRoutingModule } from './app-routing.module';

//kendo
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { GridModule, PDFModule,ExcelModule } from '@progress/kendo-angular-grid';

import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { HomeComponent } from './home/home.component';
import { AuthGuardGuard } from './auth-guard.guard';
//services
import { AuthenticationService } from './shared/services/authentication/authenticationService';
import { GlobalConstantService } from './shared/models/global/global-constant';

import { RegistrationWelcomeComponent } from './registration-welcome/registration-welcome.component';

import { CategoryEditComponent } from './category/category-edit/category-edit.component';
import { ContactAddComponent } from './contact/contact-add/contact-add.component';
import { ContactEditComponent } from './contact/contact-edit/contact-edit.component';
import { CategoryListingComponent } from './category/category-listing/category-listing.component';
import { ContactListingComponent } from './contact/contact-listing/contact-listing.component';
import { CategoryAddComponent } from './category/category-add/category-add.component';
import { CategoryService } from './shared/services/category/category-api.service';
import { ContactService } from './shared/services/contact/contact-api.service';
import { UrlSlugGenerator } from './shared/Helper/url-slug-generator';
import { ImportContactComponent } from './import-contact/import-contact.component';
import { SocialLoginConfirmationComponent } from './social-login-confirmation/social-login-confirmation.component';

import { SocialLoginModule, AuthServiceConfig, GoogleLoginProvider, FacebookLoginProvider,LinkedInLoginProvider, AuthService } from 'angularx-social-login';

const config = new AuthServiceConfig(
  [
    {
      id: GoogleLoginProvider.PROVIDER_ID,
      provider: new GoogleLoginProvider('Your_facebook_client_Id')
    },
    {
      id: FacebookLoginProvider.PROVIDER_ID,
      provider: new FacebookLoginProvider('Your_facebook_AppId')
    },
    {
      id: LinkedInLoginProvider.PROVIDER_ID,
      provider: new LinkedInLoginProvider('Your_Linkedin_cleintId')
    },
  ]
);

export function provideConfig() {
  return config;
}

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    DashboardComponent,
    HomeComponent,
    RegistrationWelcomeComponent,   
    CategoryAddComponent,
    CategoryEditComponent,
    CategoryListingComponent,
    ContactAddComponent,
    ContactEditComponent,    
    ContactListingComponent, ImportContactComponent, SocialLoginConfirmationComponent    
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    FormsModule,
    RecaptchaModule,
    RecaptchaFormsModule,
    ButtonsModule,
    BrowserAnimationsModule,
    GridModule, // if you need forms support 
    PDFModule,
    ExcelModule,
    SocialLoginModule
  ],
  providers: [
    AuthGuardGuard,
    AuthenticationService,
    GlobalConstantService,
    CategoryService,
    ContactService,
    UrlSlugGenerator,
    {
      provide: AuthServiceConfig,
      useFactory:provideConfig 
    }  
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
