import { Component, OnInit } from '@angular/core';

import { PageChangeEvent, GridDataResult } from '@progress/kendo-angular-grid';
import { SortDescriptor } from '@progress/kendo-data-query';
import { Router } from '@angular/router';

import { LoginResponse } from 'src/app/shared/models/global/login-response.model';
import { CurrentLoggedInUser } from 'src/app/shared/models/global/current-loggedin-user-model';
import { AuthenticationService } from 'src/app/shared/services/authentication/authenticationService';

import { CategoryService } from 'src/app/shared/services/category/category-api.service';
import { CategorySearchFilter } from 'src/app/shared/models/categories/category-search-filter';
import { GlobalBaseResponse } from 'src/app/shared/models/global/global-base-response.model';

@Component({
  selector: 'app-category-listing',
  templateUrl: './category-listing.component.html',
  styleUrls: ['./category-listing.component.css']
})
export class CategoryListingComponent implements OnInit {

  private categorySearchFilter: CategorySearchFilter = new CategorySearchFilter();
  private globalBaseResponse: GlobalBaseResponse = new GlobalBaseResponse();
  //common variables  
  private loginResponse: LoginResponse = new LoginResponse();
  private currentLoggedInUser: CurrentLoggedInUser = new CurrentLoggedInUser();

  //kendo grid settings
  public gridView: GridDataResult;
  public buttonCount: number = 5;
  public info = true;
  public type: 'numeric';
  public pageSizes: boolean = true;
  public previousNext: boolean = true;

  private searchTerm: string = '';
  private pageNumber: any = 1;
  private sortColumn = "name";
  private sortDirection = "asc";
  public pageSize = 20;
  public skip = 0;

  public multiple = false;
  public allowUnsort = false;

  //default sort directions
  public sort: SortDescriptor[] = [{
    field: 'name',
    dir: 'asc'
  }];

  constructor(private categoryService: CategoryService,
    private router: Router,
    private authenticationService: AuthenticationService) { }

  ngOnInit() {

    this.currentLoggedInUser = this.authenticationService.getCurrentUserInfo();
    this.loginResponse = this.authenticationService.getLoggedInUserInfo();

    //get list 
    this.pageNumber = 1;
    this.filterClassData();
  }
  protected pageChange({ skip, take }: PageChangeEvent): void {
    this.skip = skip;
    this.pageSize = take;
    this.getPageNumber(skip, take);

    //get list 
    this.filterClassData();
  }

  private filter(): void {
    console.log(`Search Term :${this.searchTerm}`);

    this.filterClassData();
  }

  public sortChange(sort: SortDescriptor[]): void {
    this.sort = sort;
    this.getSortOptions(sort);

    //get list 
    this.filterClassData();
  }

  private filterClassData() {
    this.initializationSearchFilter();
    let that = this;

    this.categoryService.filterCategory(that.categorySearchFilter)
      .subscribe(data => {
        var classViewModel = data;

        this.gridView = {
          data: classViewModel.model.categories,
          total: classViewModel.model.searchFilter.totalCount
        };

      });
  }

  private remove(id: any) {
    this.categoryService.removeCategory(this.loginResponse.token, id).subscribe(data => {
      this.globalBaseResponse = data;

      if (data.isSuccess) {
        this.pageNumber=1;
        //get list 
        this.filterClassData();
      }
    }, err => {

    });
  }

  private initializationSearchFilter() {
    this.categorySearchFilter.searchTerm = this.searchTerm;
    this.categorySearchFilter.sortColumn = this.sortColumn;
    this.categorySearchFilter.sortDirection = this.sortDirection;

    this.categorySearchFilter.token = this.loginResponse.token;
    this.categorySearchFilter.pageSize = this.pageSize;
    this.categorySearchFilter.pageNumber = this.pageNumber > 0 ? this.pageNumber : 1;
  }

  private getPageNumber(skip: number, pageSize: number): void {
    this.pageNumber = (skip + pageSize) / pageSize;
  }

  private getSortOptions(sort: SortDescriptor[]): void {
    this.sortColumn = sort[0].field;
    this.sortDirection = sort[0].dir;
  }

}
