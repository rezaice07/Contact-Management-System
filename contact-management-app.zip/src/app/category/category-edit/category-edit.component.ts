import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';

import { LoginResponse } from 'src/app/shared/models/global/login-response.model';
import { CurrentLoggedInUser } from 'src/app/shared/models/global/current-loggedin-user-model';
import { AuthenticationService } from 'src/app/shared/services/authentication/authenticationService';
import { GlobalBaseResponse } from 'src/app/shared/models/global/global-base-response.model';

import { CategoryService } from 'src/app/shared/services/category/category-api.service';
import { CategorySearchFilter } from 'src/app/shared/models/categories/category-search-filter';
import { CategoryModel } from 'src/app/shared/models/categories/category-model';

@Component({
  selector: 'app-category-edit',
  templateUrl: './category-edit.component.html',
  styleUrls: ['./category-edit.component.css']
})
export class CategoryEditComponent implements OnInit {

  private categorySearchFilter: CategorySearchFilter = new CategorySearchFilter();
  private globalBaseResponse: GlobalBaseResponse = new GlobalBaseResponse();
  //common variables  
  private loginResponse: LoginResponse = new LoginResponse();
  private currentLoggedInUser: CurrentLoggedInUser = new CurrentLoggedInUser();
  private model: CategoryModel = new CategoryModel();

  constructor(private categoryService: CategoryService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private authenticationService: AuthenticationService) { }

  ngOnInit() {
    this.currentLoggedInUser = this.authenticationService.getCurrentUserInfo();
    this.loginResponse = this.authenticationService.getLoggedInUserInfo();

    this.activatedRoute.params.subscribe(params => {
      this.model.id = params['id'];
      });  
      
      this.getCategoryDetails();
  }

  private getCategoryDetails() { 
    this.categoryService.getCategoryDetails(this.model.id,this.loginResponse.token)
      .subscribe(data => {
        this.model = data; 
      });
  }

  private updateCategory() {
    this.categoryService.updateCategory(this.loginResponse.token, this.model).subscribe(data => {
      this.globalBaseResponse = data;

      if (data.isSuccess) {
        this.router.navigate(['./categorylisting']);
      }
    }, err => {
      this.router.navigate([`./categorylisting`]);
    });
  } 
  

}
