import { Component, OnInit } from '@angular/core';
import { LoginResponse } from 'src/app/shared/models/global/login-response.model';
import { GlobalBaseResponse } from 'src/app/shared/models/global/global-base-response.model';
import { CurrentLoggedInUser } from 'src/app/shared/models/global/current-loggedin-user-model';
import { AuthenticationService } from 'src/app/shared/services/authentication/authenticationService';
import { Router } from '@angular/router';

import { CategoryService } from 'src/app/shared/services/category/category-api.service';
import { CategoryModel } from 'src/app/shared/models/categories/category-model';

@Component({
  selector: 'app-category-add',
  templateUrl: './category-add.component.html',
  styleUrls: ['./category-add.component.css']
})
export class CategoryAddComponent implements OnInit {
  //common variables  
  private loginResponse: LoginResponse = new LoginResponse();
  private globalBaseResponse: GlobalBaseResponse = new GlobalBaseResponse();

  private model: CategoryModel = new CategoryModel();

  constructor(private categoryService: CategoryService,
    private router: Router,
    private authenticationService: AuthenticationService) { }

  ngOnInit() {
    this.loginResponse = this.authenticationService.getLoggedInUserInfo();
  }

  private addNewCategory() {
    this.categoryService.addCategory(this.loginResponse.token, this.model).subscribe(data => {
      this.globalBaseResponse = data;

      if (data.isSuccess) {
        this.router.navigate(['./categorylisting']);
      }
    }, err => {
      this.router.navigate([`./categorylisting`]);
    });
  } 
}
