import { Component } from '@angular/core';
import { LoginResponse } from './shared/models/global/login-response.model';
import { AuthenticationService } from './shared/services/authentication/authenticationService';
import { Router } from '@angular/router';
import { CurrentLoggedInUser } from './shared/models/global/current-loggedin-user-model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  private title = 'Contact Management System';
  private loginResponse: LoginResponse = new LoginResponse();
  constructor(
     private authenticationService:AuthenticationService,
     private router:Router
  ) {
     this.loginResponse=this.authenticationService.getLoggedInUserInfo();
  }

  private logout(){ 
    localStorage.removeItem('auth_token'); 
    localStorage.removeItem('isLoggedIn'); 
    localStorage.removeItem('currentUserInfo');   
    localStorage.removeItem('userProfilePhotoUrl');      
    this.authenticationService.setLoggedInUserInfo(false,'','no',new CurrentLoggedInUser());

    this.router.navigate(['/home']);
  } 
}
