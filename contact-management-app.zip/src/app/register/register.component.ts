import { Component, OnInit } from '@angular/core';
import { LoginResponse } from '../shared/models/global/login-response.model';
import { CurrentLoggedInUser } from '../shared/models/global/current-loggedin-user-model';
import { Router } from '@angular/router';
import { AuthenticationService } from '../shared/services/authentication/authenticationService';
import { UserRegistrationModel } from '../shared/models/system-user/user-registration-model';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  private loginResponse: LoginResponse = new LoginResponse();
  private currentLoggedInUser: CurrentLoggedInUser = new CurrentLoggedInUser();
  private model: UserRegistrationModel = new UserRegistrationModel();
  private reCaptchKey: string = "";

  constructor(private router: Router,
    private authenticationService: AuthenticationService
  ) {
    this.reCaptchKey = "6Ld7nnUUAAAAACHwRZgOeQP5daVE6ScP1aUk8P4F";
  }

  ngOnInit() {
    this.redirectToLandingPage();
  }

  private registerNewUser() {
    //let's validate authentication
    this.authenticationService.registerNewUser(this.model).subscribe(data => {
      this.loginResponse = data;

      if (data.isSuccess) {       
        this.router.navigate(['./registrationconfirmation']);
      }
      else {
        this.router.navigate([`./home`]);
      }
    }, err => {
      this.router.navigate([`./home`]);
    });
  }

  redirectToLandingPage(): void {
    var loggedIn = this.authenticationService.validateLoggedInUser();
    if (loggedIn) {
      this.router.navigate([`./dashboard`]);
    }
  }
}
