﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ContactManagement.Core.Filters
{
    public class UserSearchFilter : BaseSearchFilter
    {

    }
}
