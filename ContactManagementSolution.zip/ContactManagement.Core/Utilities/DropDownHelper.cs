﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ContactManagement.Core.Utilities
{
    public class CustomDropdownItem
    {
        public string Text { get; set; }
        public string Value { get; set; }
        public bool Selected { get; set; }
    }
}
