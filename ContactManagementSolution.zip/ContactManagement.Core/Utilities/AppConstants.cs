﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ContactManagement.Core.Utilities
{
    public class AppConstants
    {
        public static class UserRoleConstants
        {
            public const int Administrator = 1;
            public const int EliteSupport = 2;
        }

        public static class StatusConstants
        {
            public const int Pending = 1;
            public const int Active = 2;
            public const int Deleted = 3;
        }

        public static class SocialLoginProviderTypeConstants
        {
            public const string Facebook = "Facebook";
            public const string Google = "Google";
            public const string LinkedIn = "LinkedIn";
        }
    }
}
