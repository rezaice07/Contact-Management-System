﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ContactManagement.Core.Utilities
{
    public static class StatusHelper
    {
        public static string GetStatusName(int status)
        {
            var convertedStatus = "";

            if (status <= 0)
                return "";
            switch (status)
            {
                case 1:
                    convertedStatus = "Inactive";
                    break;
                case 2:
                    convertedStatus = "Active";
                    break;                   
                case 3:
                    convertedStatus = "Deleted";
                    break;
            }

            return convertedStatus;
        }
    }
}
