﻿using ContactManagement.Core.Utilities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace ContactManagement.Data.Models
{
    [Table("Contact")]
    public class Contact
    {
        [Key]
        public int Id { get; set; }        
        public int CategoryId { get; set; }
        public string Name { get; set; }        
        public string Email { get; set; }        
        public string Mobile { get; set; }
        public string Address { get; set; }
        public string ProfilePicture { get; set; }        
        public int Status { get; set; }        
        public DateTime CreatedDateUtc { get; set; }        
        public int CreatedById { get; set; }
        public DateTime? ChangedDateUtc { get; set; }
        public int? ChangedById { get; set; }
       
        [ForeignKey("CategoryId")]
        public virtual Category Category { get; set; }

        [NotMapped]
        public string StatusInString => StatusHelper.GetStatusName(Status);

        [NotMapped]
        public string CreatedDateInString => CreatedDateUtc.ToShortDateString();
    }
}
