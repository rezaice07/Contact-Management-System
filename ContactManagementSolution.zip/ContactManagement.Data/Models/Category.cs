﻿using ContactManagement.Core.Utilities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;
using static ContactManagement.Core.Utilities.AppConstants;

namespace ContactManagement.Data.Models
{
    [Table("Category")]
    public class Category
    {
        [Key]
        public int Id { get; set; }        
        public string Name { get; set; }        
        public int Status { get; set; }        
        public DateTime CreatedDateUtc { get; set; }        
        public int CreatedById { get; set; }
        public DateTime? ChangedDateUtc { get; set; }
        public int? ChangedById { get; set; }      

        [NotMapped]
        public string StatusInString => StatusHelper.GetStatusName(Status);

        [NotMapped]
        public string CreatedDateInString => CreatedDateUtc.ToShortDateString();
    }
}
