﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace ContactManagement.Data.Models
{
    [Table("User")]
    public class User
    {
        [Key]
        public int Id { get; set; }
        
        public int RoleId { get; set; }
        
        public string Name { get; set; }
        
        public string Email { get; set; }
        
        public string PasswordHash { get; set; }
        
        public string PasswordSalt { get; set; }
        
        public string Mobile { get; set; }
        
        public string Address { get; set; }
        
        public string ProfilePicture { get; set; }

        public string AuthToken { get; set; }
        public string IdToken { get; set; }
        public string AuthorizationCode { get; set; }
        public string ProviderType { get; set; }

        public int Status { get; set; }
        
        public DateTime CreatedDateUtc { get; set; }

        [ForeignKey("RoleId")]
        public UserRole UserRole { get; set; }

        [NotMapped]
        public string RoleName { get; set; }
    }
}
