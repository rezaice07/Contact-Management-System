﻿using AutoMapper;
using ContactManagement.Api.Infrastructures.Controller;
using ContactManagement.Api.ViewModels.Categories;
using ContactManagement.Api.ViewModels.Contacts;
using ContactManagement.Core.Filters;
using ContactManagement.Data.Models;
using ContactManagement.Service.Categories;
using ContactManagement.Service.Contacts;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
using System;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static ContactManagement.Core.Utilities.AppConstants;

namespace ContactManagement.Api.Controllers
{
    [Route("api/[controller]")]
    public class ContactController : CoreController
    {
        #region Private Methods

        private readonly IMapper _mapper;
        private readonly IContactService _contactService;
        private readonly IConfiguration _configuration;
        private IHostingEnvironment _hostingEnvironment;

        #endregion

        #region ctor

        public ContactController(IMapper mapper,
            IConfiguration configuration,
            IContactService contactService,
            IHostingEnvironment hostingEnvironment
            )
        {
            _mapper = mapper;
            _contactService = contactService;
            _configuration = configuration;
            _hostingEnvironment = hostingEnvironment;            
        }

        #endregion

        #region List

        //POST api/contact/getcontactbyfilter 
        [Route("getcontactbyfilter")]
        [HttpPost]
        public async Task<IActionResult> GetContactByFilter(ContactSearchFilter filter)
        {
            var contacts = await _contactService.GetListByFilter(filter);

            var model = new ContactListViewModel
            {
                Contacts = contacts,
                SearchFilter = filter
            };

            return Ok(new
            {
                model = model
            });
        }

        #endregion

        #region Get Details By Id

        // GET api/contact/details/4
        [HttpGet]
        [Route("details/{contactId:int}")]
        public async Task<IActionResult> GetContactDetails(int contactId)
        {
            var contactDetails = await _contactService.GetDetailsById(contactId);

            if (contactDetails == null)
            {
                var message = "Contact not found, Please try another.";
                return Ok(new { IsSuccess = false, Message = message });
            }
            return Ok(contactDetails);
        }

        #endregion

        #region Add

        [Route("add")]
        [HttpPost]
        public async Task<ActionResult> AddNewContact([FromBody] AddEditContactViewModel model)
        {
            var newContact = _mapper.Map<Contact>(model);
            newContact.Status = StatusConstants.Active;
            newContact.CreatedById = CurrentLoginUser.Id;

            var isAddedNewContact = await _contactService.Add(newContact);

            if (!isAddedNewContact)
                return Ok(new { IsSuccess = false, Message = "There was an error while trying to add new contact!" });

            return Ok(new { IsSuccess = true, Message = "You have added successfully" });
        }

        #endregion

        #region Update

        [Route("update")]
        [HttpPost]
        public async Task<ActionResult> UpdateExistingContact([FromBody] AddEditContactViewModel model)
        {
            var contact = _mapper.Map<Contact>(model);

            contact.ChangedById = CurrentLoginUser.Id;

            var isUpdatedContact = await _contactService.Update(contact);

            if (!isUpdatedContact)
                return Ok(new { IsSuccess = false, Message = "There was an error while trying to updated contact!" });

            return Ok(new { IsSuccess = true, Message = "You have updated successfully" });
        }

        #endregion

        #region Remove

        // GET api/contact/remove/4
        [HttpGet]
        [Route("remove/{contactId:int}")]
        public async Task<IActionResult> RemoveExistingContact(int contactId)
        {
            var contactDetails = await _contactService.GetDetailsById(contactId);

            if (contactDetails == null)
            {
                var message = "Contact not found, Please try another.";
                return Ok(new { IsSuccess = false, Message = message });
            }

            contactDetails.ChangedById = CurrentLoginUser.Id;
            contactDetails.Status = StatusConstants.Deleted;

            var isRemoveContact = await _contactService.Remove(contactDetails);

            if (!isRemoveContact)
            {
                var message = "Contact not found, Please try another.";
                return Ok(new { IsSuccess = false, Message = message });
            }

            return Ok(new { IsSuccess = true, Message = "You have removed successfully" });
        }

        #endregion

        #region Import Contact

        [Route("importcontact")]
        [HttpPost]
        public async Task<ActionResult> ImportContact(
            [FromForm(Name = "uploadDocument")] IFormFile file
            )
        {
            //reference
            //https://www.talkingdotnet.com/import-export-excel-asp-net-core-2-razor-pages/
            //https://code-maze.com/upload-files-dot-net-core-angular/
            
            if(file==null || file.Length<=0)
                return Ok(new { IsSuccess = false, Message = "Imported contact list not found. Please import valid listing!" });

            int totalErrorOccurreds = 0;
            int totalImportedContact = 0;

            var fileName = file.FileName;

            fileName = fileName.Substring(0,fileName.IndexOf("_fileName"));
            var fragmentedCategoryInfo = fileName.Split(':');
            var categoryId = Convert.ToInt32( fragmentedCategoryInfo[1]);

            var actualFileName = file.FileName.Replace(":","");

            try
            {
                //IFormFile file = Request.Form.Files[0];
                string folderName = "webshared/upload/importcontacts";
                string webRootPath = _hostingEnvironment.WebRootPath;
                string newPath = Path.Combine(webRootPath, folderName);
                StringBuilder sb = new StringBuilder();

                if (!Directory.Exists(newPath))
                {
                    Directory.CreateDirectory(newPath);
                }
                if (file.Length > 0)
                {
                    string sFileExtension = Path.GetExtension(actualFileName).ToLower();
                    ISheet sheet;
                    string fullPath = Path.Combine(newPath, actualFileName);
                    using (var stream = new FileStream(fullPath, FileMode.Create))
                    {
                        file.CopyTo(stream);
                        stream.Position = 0;

                        if (sFileExtension == ".xls")
                        {
                            HSSFWorkbook hssfwb = new HSSFWorkbook(stream); //This will read the Excel 97-2000 formats  
                            sheet = hssfwb.GetSheetAt(0); //get first sheet from workbook  
                        }
                        else
                        {
                            XSSFWorkbook hssfwb = new XSSFWorkbook(stream); //This will read 2007 Excel format  
                            sheet = hssfwb.GetSheetAt(0); //get first sheet from workbook   
                        }

                        IRow headerRow = sheet.GetRow(0); //Get Header Row
                        int cellCount = headerRow.LastCellNum;

                        totalImportedContact = sheet.LastRowNum;

                        for (int i = (sheet.FirstRowNum + 1); i <= sheet.LastRowNum; i++) //Read Excel File
                        {
                            IRow row = sheet.GetRow(i);
                            if (row == null)
                            {
                                totalErrorOccurreds += 1;
                                continue;
                            }

                            if (row.Cells.All(d => d.CellType == CellType.Blank))
                            {
                                totalErrorOccurreds += 1;
                                continue;
                            }
                          
                            var newContact = new Contact
                            {
                                CategoryId = categoryId,
                                Name = row.GetCell(0) != null ? row.GetCell(0).ToString() : "",
                                Email = row.GetCell(1) != null ? row.GetCell(1).ToString() : "",
                                Mobile = row.GetCell(2) != null ? row.GetCell(2).ToString() : "",
                                Address = row.GetCell(3) != null ? row.GetCell(3).ToString() : "",
                                CreatedById = CurrentLoginUser.Id,
                                Status = StatusConstants.Active
                            };

                            var isAdded = await _contactService.Add(newContact);
                            if (!isAdded)
                                totalErrorOccurreds += 1;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return Ok(new { IsSuccess = false, Message = "There was an error while contact import!" });
            }

            if (totalErrorOccurreds>0)
                return Ok(new { IsSuccess = true, Message = "Contact imported partially!" });

            return Ok(new { IsSuccess = true, Message = "Contact Imported successfully" });
        }

        #endregion

    }
}
