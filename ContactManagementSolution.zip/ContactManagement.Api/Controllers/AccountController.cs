﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using ContactManagement.Api.ViewModels.Accounts;
using ContactManagement.Data.Models;
using ContactManagement.Service.Encriptions;
using ContactManagement.Service.Users;
using static ContactManagement.Core.Utilities.AppConstants;

namespace ContactManagement.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        #region Private Member

        private readonly IMapper _mapper;
        private readonly IUserService _userService;
        private readonly IConfiguration _configuration;

        #endregion

        #region Ctor

        public AccountController(IMapper mapper,
            IConfiguration configuration,
            IUserService userService
            )
        {
            _mapper = mapper;
            _userService = userService;
            _configuration = configuration;
        }
        #endregion

        #region Login

        [Route("login")]
        [HttpPost]
        public async Task<ActionResult> Login([FromBody] LoginViewModel model)
        {
            //get user info by email
            var user = await _userService.GetDetailsByEmail(model.Email);

            if (user == null)
                return Ok(new { IsSuccess = false, Message = "Incorrect email or password.!" });

            //check valid user
            if (ValidateLoggedInUser(model, user))
            {
                var message = "Incorrect email or password, Please try again.";
                return Ok(new { IsSuccess = false, Message = message });
            }

            //creating custom claims
            var claims = new[] {
                    new Claim("Id", user.Id.ToString()),
                    new Claim("Mobile", user.Mobile),
                    new Claim("Email", user.Email),
                    new Claim("Name", user.Name),
                    new Claim("ProfilePicture", user.ProfilePicture??""),
                    new Claim("RoleId", user.RoleId.ToString()),
                    new Claim("RoleName", user.UserRole.RoleName)
                };

            //get signing key
            var signinKey = new SymmetricSecurityKey(
              Encoding.UTF8.GetBytes(_configuration["Jwt:SigningKey"]));

            //get token expire
            int expiryInMinutes = Convert.ToInt32(_configuration["Jwt:ExpiryInMinutes"]);

            //generating a new jwt token with additional information
            var token = new JwtSecurityToken(
              claims: claims,
              issuer: _configuration["Jwt:Site"],
              audience: _configuration["Jwt:Site"],
              expires: DateTime.UtcNow.AddMinutes(expiryInMinutes),
              signingCredentials: new SigningCredentials(signinKey, SecurityAlgorithms.HmacSha256)
            );

            return Ok(
              new
              {
                  isSuccess = true,
                  message = "Login Successfull!",
                  token = new JwtSecurityTokenHandler().WriteToken(token),
                  expiration = token.ValidTo,
                  currentUser = user
              });
        }

        #endregion

        #region Register as Normal User

        [Route("register")]
        [HttpPost]
        public async Task<ActionResult> RegisterNewUser([FromBody] UserRegistrationViewModel model)
        {
            var existingUser = await _userService.GetDetailsByEmail(model.Email);

            if (existingUser != null)
                return Ok(new { IsSuccess = false, Message = $"Email already exist. Please try another!" });

            var newUser = _mapper.Map<User>(model);
            newUser.RoleId = UserRoleConstants.EliteSupport;
            newUser.Status = StatusConstants.Active;

            var isRegistered = await _userService.AddNormalUser(newUser);

            if (!isRegistered)
                return Ok(new { IsSuccess = false, Message = "There was an error while trying to register!" });

            return Ok(new { IsSuccess = true, Message = "You have registered successfully" });
        }

        #endregion

        #region Register With Social Media

        [Route("registerassocialmedia")]
        [HttpPost]
        public async Task<ActionResult> RegisterSocialMedialNewUser([FromBody] UserRegistrationViewModel model)
        {
            var existingUser = await _userService.GetDetailsByEmail(model.Email);

            //if user already register then proceed to login
            if (existingUser != null)            
                return LoginWithSocialMedia(existingUser);           

            var newUser = _mapper.Map<User>(model);
            newUser.RoleId = UserRoleConstants.EliteSupport;
            newUser.Status = StatusConstants.Active;

            var isRegistered = await _userService.AddSocialMediaUser(newUser);

            if (!isRegistered)            
                return Ok(new { IsSuccess = false, Message = "There was an error while trying to login!" });

            existingUser = await _userService.GetDetailsByEmail(model.Email);
            return LoginWithSocialMedia(existingUser);
        }

        private ActionResult LoginWithSocialMedia(User existingUser)
        {
            //check valid user  
            if (existingUser.Status != StatusConstants.Active)
            {
                var message = "Your account looks inactive, Please contact with support.";
                return Ok(new { IsSuccess = false, Message = message });
            }

            //creating custom claims
            var claims = new[] {
                    new Claim("Id", existingUser.Id.ToString()),
                    new Claim("Mobile", existingUser.Mobile??""),
                    new Claim("Email", existingUser.Email),
                    new Claim("Name", existingUser.Name),
                    new Claim("ProfilePicture", existingUser.ProfilePicture??""),
                    new Claim("RoleId", existingUser.RoleId.ToString()),
                    new Claim("RoleName", existingUser.UserRole.RoleName)
                };

            //get signing key
            var signinKey = new SymmetricSecurityKey(
              Encoding.UTF8.GetBytes(_configuration["Jwt:SigningKey"]));

            //get token expire
            int expiryInMinutes = Convert.ToInt32(_configuration["Jwt:ExpiryInMinutes"]);

            //generating a new jwt token with additional information
            var token = new JwtSecurityToken(
              claims: claims,
              issuer: _configuration["Jwt:Site"],
              audience: _configuration["Jwt:Site"],
              expires: DateTime.UtcNow.AddMinutes(expiryInMinutes),
              signingCredentials: new SigningCredentials(signinKey, SecurityAlgorithms.HmacSha256)
            );

            return Ok(
              new
              {
                  isSuccess=true,
                  message="Login Successfull!",
                  token = new JwtSecurityTokenHandler().WriteToken(token),
                  expiration = token.ValidTo,
                  currentUser = existingUser
              });
        }

        #endregion

        #region Private Methods

        private bool ValidateLoggedInUser(LoginViewModel model, User user)
        {
            return user.Status != StatusConstants.Active 
                && user.PasswordHash != EncryptionService.HashPassword(model.Password, user.PasswordSalt);
        }

        #endregion
    }
}
