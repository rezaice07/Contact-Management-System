﻿using AutoMapper;
using ContactManagement.Api.Infrastructures.Controller;
using ContactManagement.Api.ViewModels.Categories;
using ContactManagement.Core.Filters;
using ContactManagement.Data.Models;
using ContactManagement.Service.Categories;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System.Threading.Tasks;
using static ContactManagement.Core.Utilities.AppConstants;

namespace CategoryManagement.Api.Controllers
{
    [Route("api/[controller]")]
    public class CategoryController : CoreController
    {
        #region Private Methods

        private readonly IMapper _mapper;
        private readonly ICategoryService _categoryService;
        private readonly IConfiguration _configuration;
        #endregion

        #region ctor

        public CategoryController(IMapper mapper,
            IConfiguration configuration,
            ICategoryService categoryService
            )
        {
            _mapper = mapper;
            _categoryService = categoryService;
            _configuration = configuration;
        }

        #endregion

        #region List

        //POST api/category/getcategorybyfilter 
        [Route("getcategorybyfilter")]
        [HttpPost]
        public async Task<IActionResult> GetCategoryByFilter(CategorySearchFilter filter)
        {            
            var categoryes = await _categoryService.GetListByFilter(filter);

            var model = new CategoryListViewModel
            {
                Categories = categoryes,
                SearchFilter = filter
            };

            return Ok(new
            {
                model = model
            });
        }

        #endregion

        #region Get Details By Id

        // GET api/category/details/4
        [HttpGet]        
        [Route("details/{categoryId:int}")]
        public async Task<IActionResult> GetCategoryDetails(int categoryId)
        {
            var categoryDetails = await _categoryService.GetDetailsById(categoryId);

            if (categoryDetails == null)
            {
                var message = "Category not found, Please try another.";
                return Ok(new { IsSuccess = false, Message = message });
            }
            return Ok(categoryDetails);
        }

        #endregion

        #region Add

        [Route("add")]
        [HttpPost]
        public async Task<ActionResult> AddNewCategory(AddEditCategoryViewModel model)
        {
            var currentUser= CurrentLoginUser; 
            var newCategory = _mapper.Map<Category>(model);
            newCategory.Status = StatusConstants.Active;
            newCategory.CreatedById = currentUser.Id;

            var isAddedNewCategory = await _categoryService.Add(newCategory);

            if (!isAddedNewCategory)
                return Ok(new { IsSuccess = false, Message = "There was an error while trying to add new category!" });

            return Ok(new { IsSuccess = true, Message = "You have added successfully" });
        }

        #endregion

        #region Update

        [Route("update")]
        [HttpPost]
        public async Task<ActionResult> UpdateExistingCategory([FromBody] AddEditCategoryViewModel model)
        {
            var category = _mapper.Map<Category>(model);
            category.ChangedById = CurrentLoginUser.Id;
            var isUpdatedCategory = await _categoryService.Update(category);

            if (!isUpdatedCategory)
                return Ok(new { IsSuccess = false, Message = "There was an error while trying to updated category!" });

            return Ok(new { IsSuccess = true, Message = "You have updated successfully" });
        }

        #endregion

        #region Remove

        // GET api/category/remove/4
        [HttpGet]
        [Route("remove/{categoryId:int}")]
        public async Task<IActionResult> RemoveExistingCategory(int categoryId)
        {
            var categoryDetails = await _categoryService.GetDetailsById(categoryId);

            if (categoryDetails == null)
            {
                var message = "Category not found, Please try another.";
                return Ok(new { IsSuccess = false, Message = message });
            }

            categoryDetails.ChangedById = CurrentLoginUser.Id;

            var isRemoveCategory = await _categoryService.Remove(categoryDetails);

            if (!isRemoveCategory)
            {
                var message = "Category not found, Please try another.";
                return Ok(new { IsSuccess = false, Message = message });
            }

            return Ok(new { IsSuccess = true, Message = "You have removed successfully" });
        }

        #endregion

        #region DropdownList

        //POST api/category/getcategorybyfilter 
        [Route("getcategorydropdownitems")]
        [HttpGet]
        public async Task<IActionResult> GetCategoryDropdownItems()
        {
            var categories = await _categoryService.GetListForDropdown();
                        
            return Ok(new
            {
                categories
            });
        }

        #endregion
    }
}
