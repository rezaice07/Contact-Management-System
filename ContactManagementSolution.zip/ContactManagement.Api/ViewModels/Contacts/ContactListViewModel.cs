﻿using System.Collections.Generic;
using ContactManagement.Core.Filters;
using ContactManagement.Data.Models;

namespace ContactManagement.Api.ViewModels.Contacts
{
    public class ContactListViewModel
    {
        public IEnumerable<Contact> Contacts { get; set; }
        public ContactSearchFilter SearchFilter { get; set; }
    }
}
