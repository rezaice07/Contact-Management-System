﻿using System.Collections.Generic;
using ContactManagement.Core.Filters;
using ContactManagement.Data.Models;

namespace ContactManagement.Api.ViewModels.Contacts
{
    public class AddEditContactViewModel
    {
        public int Id { get; set; }
        public int CategoryId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }
        public string Address { get; set; }
        public string ProfilePicture { get; set; }
    }
}
