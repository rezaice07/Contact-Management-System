﻿using System.Collections.Generic;
using ContactManagement.Core.Filters;
using ContactManagement.Data.Models;
using Microsoft.AspNetCore.Http;

namespace ContactManagement.Api.ViewModels.Categories
{
    public class AddEditCategoryViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
