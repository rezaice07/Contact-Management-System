﻿using System.Collections.Generic;
using ContactManagement.Core.Filters;
using ContactManagement.Data.Models;

namespace ContactManagement.Api.ViewModels.Categories
{
    public class CategoryListViewModel
    {
        public IEnumerable<Category> Categories { get; set; }
        public CategorySearchFilter SearchFilter { get; set; }
    }
}
