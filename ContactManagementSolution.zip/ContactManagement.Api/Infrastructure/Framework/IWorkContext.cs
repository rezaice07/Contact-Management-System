﻿using ContactManagement.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ContactManagement.Api.Infrastructure.Framework
{
    public interface IWorkContext
    {
        /// <summary>
        ///  Gets or sets the current logged in user
        /// </summary>
        User CurrentLoggedInUser { get; set; }
    }
}
