﻿using ContactManagement.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace ContactManagement.Api.Infrastructure.Framework
{
    public class WebWorkContext : IWorkContext
    {
        #region Private Members

        private User _cacheLoggedInUser;

        #endregion

        #region Ctor

        public WebWorkContext()
        {
        }

        #endregion

        #region Public Methods

        public User CurrentLoggedInUser
        {
            get => GetCurrentLoggedInUser();
            set => _cacheLoggedInUser = value;
        }
        #endregion

        #region Private Methods

        /// <summary>
        ///     Gets the current logged in user
        /// </summary>
        /// <returns></returns>
        private User GetCurrentLoggedInUser()
        {
            var userModel = new User();

            //if (!Microsoft.AspNetCore.Mvc.User.Identity.IsAuthenticated)
            //    return userModel;

            //var claimsIdentity = (ClaimsIdentity)User.Identity;
            //var userClaims = claimsIdentity.Claims;

            //if (userClaims == null)
            //    return new User();

            //userModel.Id = Convert.ToInt32(claimsIdentity.Claims.FirstOrDefault(f => f.Type == "Id").Value);
            //userModel.Email = claimsIdentity.Claims.FirstOrDefault(f => f.Type == "Email").Value;
            //userModel.Name = claimsIdentity.Claims.FirstOrDefault(f => f.Type == "FirstName").Value;
            //userModel.RoleId = Convert.ToInt32(claimsIdentity.Claims.FirstOrDefault(f => f.Type == "RoleId").Value);
            //userModel.RoleName = claimsIdentity.Claims.FirstOrDefault(f => f.Type == "RoleName").Value;
            //userModel.Mobile = claimsIdentity.Claims.FirstOrDefault(f => f.Type == "Mobile").Value;
            return userModel;
        }
        #endregion

    }
}
