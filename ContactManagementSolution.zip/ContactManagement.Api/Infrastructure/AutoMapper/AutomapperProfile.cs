﻿using AutoMapper;
using ContactManagement.Api.ViewModels.Accounts;
using ContactManagement.Api.ViewModels.Categories;
using ContactManagement.Api.ViewModels.Contacts;
using ContactManagement.Data.Models;

namespace ContactManagement.Api.Infrastructures.AutoMapper
{
    public class AutomapperProfile : Profile
    {
        public AutomapperProfile()
        {
            CreateMap<User, UserRegistrationViewModel>().ReverseMap();
            CreateMap<User, LoginViewModel>().ReverseMap();

            CreateMap<Contact, AddEditContactViewModel>().ReverseMap();
            CreateMap<Category, AddEditCategoryViewModel>().ReverseMap();
        }
    }
}
