﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;
using System.Security.Claims;
using ContactManagement.Data.Models;

namespace ContactManagement.Api.Infrastructures.Controller
{
    [Authorize]
    [ApiController]
    public class CoreController : ControllerBase
    {
        public User CurrentLoginUser
        {
            get
            {
                var userModel = new User();

                if (!User.Identity.IsAuthenticated)
                    return userModel;

                var claimsIdentity = (ClaimsIdentity)User.Identity;
                var userClaims = claimsIdentity.Claims;

                if (userClaims == null)
                    return new User();

                userModel.Id = Convert.ToInt32(claimsIdentity.Claims.FirstOrDefault(f => f.Type == "Id").Value);
                userModel.Email = claimsIdentity.Claims.FirstOrDefault(f => f.Type == "Email").Value;
                userModel.Name = claimsIdentity.Claims.FirstOrDefault(f => f.Type == "Name").Value;
                userModel.RoleId = Convert.ToInt32(claimsIdentity.Claims.FirstOrDefault(f => f.Type == "RoleId").Value);
                userModel.RoleName = claimsIdentity.Claims.FirstOrDefault(f => f.Type == "RoleName").Value;
                userModel.Mobile = claimsIdentity.Claims.FirstOrDefault(f => f.Type == "Mobile").Value;
                return userModel;
            }
        }       
    }
}
