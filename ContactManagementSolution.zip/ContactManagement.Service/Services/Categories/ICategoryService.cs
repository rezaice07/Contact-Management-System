﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ContactManagement.Core.Filters;
using ContactManagement.Core.Utilities;
using ContactManagement.Data.Models;

namespace ContactManagement.Service.Categories
{
    public interface ICategoryService
    {
        Task<IEnumerable<Category>> GetListByFilter(CategorySearchFilter filter);
        Task<Category> GetDetailsById(int id);
        Task<IEnumerable<CustomDropdownItem>> GetListForDropdown();
        Task<bool> Add(Category newCategoryModel);
        Task<bool> Update(Category categoryModel);
        Task<bool> Remove(Category updateCategoryModel);
    }
}
