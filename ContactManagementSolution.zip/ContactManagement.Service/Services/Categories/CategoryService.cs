﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using System.Transactions;
using ContactManagement.Core.Filters;
using ContactManagement.Core.Utilities;
using ContactManagement.Data.Models;
using static ContactManagement.Core.Utilities.AppConstants;

namespace ContactManagement.Service.Categories
{
    public class CategoryService : ICategoryService
    {
        #region Private Member
        private readonly ContactManagementDbContext db;

        #endregion

        #region Ctor

        public CategoryService(ContactManagementDbContext db)
        {
            this.db = db;
        }

        #endregion

        #region public Methods     

        public Task<IEnumerable<Category>> GetListByFilter(CategorySearchFilter filter)
        {
            List<Category> classList = new List<Category>();

            var query = db.Categories
                            .Where(f =>
                            (f.Status != StatusConstants.Deleted) &&
                            (filter.Status == null || filter.Status == string.Empty || f.Status == Convert.ToInt32(filter.Status)) &&
                            (filter.SearchTerm == string.Empty || f.Name.Contains(filter.SearchTerm.Trim())));
                       
            filter.TotalCount = query.Count();

            //sorting 
            Func<Category, object> OrderByStringField = null;

            switch (filter.SortColumn)
            {
                case "Name":
                    OrderByStringField = p => p.Name;
                    break;                
                default:
                    OrderByStringField = p => p.Name;
                    break;
            }
            //end sorting  

            var finalQuery = filter.SortDirection == "ASC" ? query.OrderBy(OrderByStringField) : query.OrderByDescending(OrderByStringField);

            classList = finalQuery.Skip((filter.PageNumber - 1) * filter.PageSize)
                                        .Take(filter.PageSize)
                                        .AsParallel()
                                        .ToList();
            return Task.Run(()=> classList.AsEnumerable());
        }

        public Task<Category> GetDetailsById(int id)
        {
            var singleCategory = db.Categories
                .FirstOrDefault(d => d.Id == id);

            return Task.Run(() => singleCategory);

        }
        public Task<IEnumerable<CustomDropdownItem>> GetListForDropdown()
        {
            var categories = db.Categories.ToList();

            var listings = categories.Select(f => new CustomDropdownItem
            {
                Text = $"{f.Name}",
                Value = f.Id.ToString(CultureInfo.InvariantCulture)
            }).AsEnumerable();

            return Task.Run(() => listings);

        }
        public Task<bool> Add(Category newCategoryModel)
        {
            try
            {
                var currentDate = DateTime.UtcNow;
                newCategoryModel.CreatedDateUtc = currentDate;

                db.Categories.Add(newCategoryModel);
                db.SaveChanges();
                return Task.Run(() => true);
            }
            catch
            {
                return Task.Run(() => false);
            }
        }

        public Task<bool> Update(Category updatedCategoryModel)
        {
            try
            {
                var currentDate = DateTime.UtcNow;
                var upateCategory = db.Categories.FirstOrDefault(d => d.Id == updatedCategoryModel.Id);

                if (upateCategory == null)
                    return Task.Run(() => false);

                upateCategory.Name = updatedCategoryModel.Name;
                upateCategory.ChangedById = updatedCategoryModel.ChangedById;
                upateCategory.ChangedDateUtc = currentDate;
                db.SaveChanges();

                return Task.Run(() => true);
            }
            catch
            {
                return Task.Run(() => false);
            }
        }

        public Task<bool> Remove(Category removeCategoryModel)
        {
            try
            {
                var removeCategory = db.Categories.FirstOrDefault(d => d.Id == removeCategoryModel.Id);

                if (removeCategory == null)
                    return Task.Run(() => false);
                removeCategory.Status = StatusConstants.Deleted;

                db.SaveChanges();

                return Task.Run(() => true);
            }
            catch
            {
                return Task.Run(() => false);
            }
        }

        #endregion
    }
}
