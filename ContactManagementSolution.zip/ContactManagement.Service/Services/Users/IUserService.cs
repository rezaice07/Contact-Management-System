﻿
using System.Collections.Generic;
using System.Threading.Tasks;
using ContactManagement.Data.Models;

namespace ContactManagement.Service.Users
{
    public interface IUserService
    {
        Task<User> GetDetailsById(int id);
        Task<User> GetDetailsByEmail(string email);
        Task<bool> ResetPassword(User user);
        Task<bool> AddNormalUser(User user);
        Task<bool> AddSocialMediaUser(User newUserModel);
        Task<bool> Update(User user);
        Task<bool> Remove(User user);
    }
}
