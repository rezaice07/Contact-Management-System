﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;
using ContactManagement.Data.Models;
using ContactManagement.Service.Encriptions;

namespace ContactManagement.Service.Users
{
    public class UserService : IUserService
    {
        #region Private Member
        private readonly ContactManagementDbContext db;

        #endregion

        #region Ctor

        public UserService(ContactManagementDbContext db)
        {
            this.db = db;
        }

        #endregion

        #region public Methods      

        public Task<User> GetDetailsById(int id)
        {
            var user = db.Users
                .FirstOrDefault(d => d.Id == id);

            return Task.Run(()=>user);

        }

        public Task<User> GetDetailsByEmail(string email)
        {
            var user = db.Users                
                .Include(i => i.UserRole)
                .FirstOrDefault(d => d.Email == email);

            return Task.Run(() => user);
        }

        public Task<bool> AddNormalUser(User newUserModel)
        {
            var currentDate = DateTime.UtcNow;

            try
            {
                //create salt and password hash
                var randomPass = EncryptionService.GenerateRandomPassword(8);
                var salt = EncryptionService.CreateRandomSalt();
                var passwordHash = EncryptionService.HashPassword(randomPass, salt);

                newUserModel.PasswordHash = passwordHash;
                newUserModel.PasswordSalt = salt;
                newUserModel.CreatedDateUtc = currentDate;

                db.Users.Add(newUserModel);
                db.SaveChanges();

                return Task.Run(() => true);
            }
            catch(Exception ex)
            {
                return Task.Run(() => false);
            }
        }
        public Task<bool> AddSocialMediaUser(User newUserModel)
        {
            var currentDate = DateTime.UtcNow;

            try
            {                   
                newUserModel.CreatedDateUtc = currentDate;

                db.Users.Add(newUserModel);
                db.SaveChanges();

                return Task.Run(() => true);
            }
            catch (Exception ex)
            {
                return Task.Run(() => false);
            }
        }

        public Task<bool> Update(User user)
        {
            try
            {
                var upateUser = db.Users.FirstOrDefault(d => d.Id == user.Id);

                if (upateUser == null)
                    return Task.Run(() => false);

                upateUser.Name = user.Name;

                db.SaveChanges();

                return Task.Run(() => true);
            }
            catch
            {
                return Task.Run(() => false);
            }
        }        

        public Task<bool> Remove(User user)
        {
            try
            {
                var removeUser = db.Users.FirstOrDefault(d => d.Id == user.Id);

                if (removeUser == null)
                    return Task.Run(() => false);
                removeUser.Status = user.Status;

                db.SaveChanges();

                return Task.Run(() => true);
            }
            catch
            {
                return Task.Run(() => false);
            }
        }

        public Task<bool> ResetPassword(User user)
        {
            try
            {
                var updateUser = db.Users.FirstOrDefault(d => d.Id == user.Id);

                if (updateUser == null)
                    return Task.Run(() => false);

                var randomPass = EncryptionService.GenerateRandomPassword(8);
                var salt = EncryptionService.CreateRandomSalt();
                var passwordHash = EncryptionService.HashPassword(randomPass, salt);

                updateUser.PasswordHash = passwordHash;
                updateUser.PasswordSalt = salt;

                db.SaveChanges();

                return Task.Run(() => true);
            }
            catch
            {
                return Task.Run(() => false);
            }
        }

        #endregion
    }
}
