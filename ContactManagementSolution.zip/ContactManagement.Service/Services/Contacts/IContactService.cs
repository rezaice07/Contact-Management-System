﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ContactManagement.Core.Filters;
using ContactManagement.Core.Utilities;
using ContactManagement.Data.Models;

namespace ContactManagement.Service.Contacts
{
    public interface IContactService
    {
        Task<IEnumerable<Contact>> GetListByFilter(ContactSearchFilter filter);
        Task<Contact> GetDetailsById(int id);        
        Task<bool> Add(Contact newContactModel);
        Task<bool> Update(Contact categoryModel);
        Task<bool> Remove(Contact updateContactModel);
    }
}
