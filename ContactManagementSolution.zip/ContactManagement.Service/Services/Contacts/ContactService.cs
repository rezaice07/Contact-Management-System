﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using System.Transactions;
using ContactManagement.Core.Filters;
using ContactManagement.Core.Utilities;
using ContactManagement.Data.Models;
using ContactManagement.Service.Contacts;
using Microsoft.EntityFrameworkCore;
using static ContactManagement.Core.Utilities.AppConstants;

namespace ContactManagement.Service.Contacts
{
    public class ContactService : IContactService
    {
        #region Private Member
        private readonly ContactManagementDbContext db;

        #endregion

        #region Ctor

        public ContactService(ContactManagementDbContext db)
        {
            this.db = db;
        }

        #endregion

        #region public Methods     

        public Task<IEnumerable<Contact>> GetListByFilter(ContactSearchFilter filter)
        {
            List<Contact> contactList = new List<Contact>();

            var query = db.Contacts
                            .Include(f => f.Category)
                            .Where(f =>
                            (f.Status != StatusConstants.Deleted) &&
                            (filter.Status == null || filter.Status == string.Empty || f.Status == Convert.ToInt32(filter.Status)) &&
                            (filter.SearchTerm == string.Empty || f.Name.Contains(filter.SearchTerm.Trim())
                            || f.Category.Name.Contains(filter.SearchTerm.Trim())
                            || f.Email.Contains(filter.SearchTerm.Trim())
                            || f.Mobile.Contains(filter.SearchTerm.Trim())
                            ));

            filter.TotalCount = query.Count();

            //sorting 
            Func<Contact, object> OrderByStringField = null;

            switch (filter.SortColumn.ToLower())
            {
                case "category.name":
                    OrderByStringField = p => p.Category.Name;
                    break;
                case "name":
                    OrderByStringField = p => p.Name;
                    break;
                case "email":
                    OrderByStringField = p => p.Email;
                    break;

                case "mobile":
                    OrderByStringField = p => p.Mobile;
                    break;

                case "address":
                    OrderByStringField = p => p.Address;
                    break;

                default:
                    OrderByStringField = p => p.Name;
                    break;
            }
            //end sorting  

            var finalQuery = filter.SortDirection.ToLower() == "asc" ? query.OrderBy(OrderByStringField) : query.OrderByDescending(OrderByStringField);

            contactList = finalQuery.Skip((filter.PageNumber - 1) * filter.PageSize)
                                        .Take(filter.PageSize)
                                        .AsParallel()
                                        .ToList();
            return Task.Run(() => contactList.AsEnumerable());
        }
        public Task<Contact> GetDetailsById(int id)
        {
            var singleContact = db.Contacts
                .Include(i=>i.Category)
                .FirstOrDefault(d => d.Id == id);

            return Task.Run(() => singleContact);

        }
        public Task<bool> Add(Contact newContactModel)
        {
            try
            {
                var currentDate = DateTime.UtcNow;
                newContactModel.CreatedDateUtc = currentDate;

                db.Contacts.Add(newContactModel);
                db.SaveChanges();
                return Task.Run(() => true);
            }
            catch
            {
                return Task.Run(() => false);
            }
        }
        public Task<bool> Update(Contact updatedContactModel)
        {
            try
            {
                var currentDate = DateTime.UtcNow;

                var upateContact = db.Contacts.FirstOrDefault(d => d.Id == updatedContactModel.Id);

                if (upateContact == null)
                    return Task.Run(() => false);

                upateContact.CategoryId = updatedContactModel.CategoryId;
                upateContact.Name = updatedContactModel.Name;
                upateContact.Email = updatedContactModel.Email;
                upateContact.Mobile = updatedContactModel.Mobile;
                upateContact.Address = updatedContactModel.Address;

                upateContact.ChangedById = updatedContactModel.ChangedById;
                upateContact.ChangedDateUtc = currentDate;

                db.SaveChanges();

                return Task.Run(() => true);
            }
            catch
            {
                return Task.Run(() => false);
            }
        }
        public Task<bool> Remove(Contact removeContactModel)
        {
            try
            {
                var removeContact = db.Contacts.FirstOrDefault(d => d.Id == removeContactModel.Id);

                if (removeContact == null)
                    return Task.Run(() => false);
                removeContact.Status = removeContact.Status;
                removeContact.ChangedById = removeContact.ChangedById;
                removeContact.ChangedDateUtc = DateTime.UtcNow;

                db.SaveChanges();

                return Task.Run(() => true);
            }
            catch
            {
                return Task.Run(() => false);
            }
        }

        #endregion
    }
}
