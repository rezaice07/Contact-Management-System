﻿using Microsoft.EntityFrameworkCore;
using System;
using ContactManagement.Data.Models;

namespace ContactManagement.Service
{
    public class ContactManagementDbContext : DbContext
    {
        public ContactManagementDbContext(DbContextOptions<ContactManagementDbContext> options)
            : base(options)
        {

        }
        
        public DbSet<User> Users { get; set; }
        public DbSet<UserRole> UserRoles { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Contact> Contacts { get; set; }
    }    
}
